# Capstone: Taobao Recommender System

## Problem Statement
Build a recommendation engine to help users in their selection of suitable items sold in e-Commerce giant, Taobao. Based on the individual user's preference from their buying history, page views, add-to-cart items and favorite items, the recommender will output the top 10 most suitable products for each user. 

## Data Set
Data was downloaded from Alibaba Cloud (URL: https://tianchi.aliyun.com/dataset/dataDetail?dataId=649). It includes user behavior data from 25 November 2017 to 3 December 2017.

## Executive Summary
- Data extraction and cleaning
- Exploratory data analysis
- Recommender System
- Model Evaluation

## Approach
Data: The data comprised of implicit taobao's customer information such as user ID, item ID, category ID, user behavior type and date.
Feature Engineering: Data was cleaned and all features was selected as they were all required as inputs to the final recommendation engine.
Model: Alternating Least Squares (ALS). A baseline model was represented by obtaining the most popular items from collated user behavior data.
Evaluation: The AUC score was computed for the individual users, and the mean AUC score was used to compare the baseline with the recommender system.

## Conclusion

Based on a total of 10,000 users producing 3.7 million user behavioral actions, an implicit recommendation system was implemented to generate the top 10 most suitable items for each user, based on item and user similarity, as well as the interaction scores each user has with the iterms interacted. The mean AUC score of the ALS model (0.911) was significantly higher than the mean AUC score of the baseline model (0.647).

Relevant information which could be useful for future recommendation systems:
- Price of each item
- Name of each item and category
- User behavior on special dates (e.g. 11.11, Black Friday, Valentine's Day)
- Explicit data (e.g. user review and rating)
