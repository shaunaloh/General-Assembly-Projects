from flask import Flask, request
import pickle
import telegram
from telebot.credentials import bot_token, bot_user_name,URL
from telegram.ext import Updater, CommandHandler, CallbackQueryHandler, ConversationHandler, MessageHandler, Filters
import pandas as pd
import numpy as np

global bot
global TOKEN
TOKEN = bot_token
bot = telegram.Bot(token=TOKEN)
updater = Updater(token, use_context=True)
FIRST, SECOND = range(2)
dispatcher = updater.dispatcher
updater.stop()

# load the files
df_bot_pv = pickle.load(open('./df_bot_pv.pkl', 'rb'))
df_bot_cart = pickle.load(open('./df_bot_cart.pkl', 'rb'))
df_bot_fav = pickle.load(open('./df_bot_fav.pkl', 'rb'))
df_bot_buy = pickle.load(open('./df_bot_buy.pkl', 'rb'))

app = Flask(__name__)

@app.route('/start', methods=['POST'])
def start(update, context):
    context.bot.send_photo(chat_id=update.message.chat_id, photo=open('C:/Users/User/Pictures/welcome_taobao.JPG', 'rb'))
    context.bot.send_message(chat_id = update.message.chat_id, text = "Welcome to mytaobao! We provide you recommendations on taobao products for your consideration!"+"\n\n"+"To facilitate your user experience, feel free to explore our list of commands below anytime you wish to do so!"+ "\n\n" + "/start : to start mytaobao bot!"+"\n"+"/help : our friendly bot will assist you in answering a list of common FAQs!"+"\n"+"/links : photos and URLs to our top 10 best selling products!"+"\n"+"/exit : there is always a time to say goodbye. Hope we have served you well!"+"\n\n"+" Firstly, how may I address you?")
    return FIRST

@app.route('/name', methods=['POST'])
def name(txt):
    return "Hi "+ str(txt)+ "! " + "Please provide us your User ID."

@app.route('/response', methods=['POST'])
def response(num):
    try:
        if num.isdigit() == False:
            return 'Invalid input. Please key in valid User ID.'
        #existing user ids fall within 0 to 4830.
        if int(num) in range(0,4831):
            
            #case 1: pv + cart + fav + buy
            if int(num) in df_bot_pv['User ID'].unique():
                if int(num) in df_bot_cart['User ID'].unique():
                    if int(num) in df_bot_fav['User ID'].unique():
                        if int(num) in df_bot_buy['User ID'].unique():
                            return 'Welcome back! Based on your past consumer history, we wish to recommend the following items to you:  \n\n'+ 'Top 10 most viewed items: ' + str(list(df_bot_pv[df_bot_pv['User ID']==int(num)]['Item ID'])) + '\n\n Top 10 most add to cart items: ' + str(list(df_bot_cart[df_bot_cart['User ID']==int(num)]['Item ID'])) + ' \n\n Top 10 most favorite items: ' + str(list(df_bot_fav[df_bot_fav['User ID']==int(num)]['Item ID'])) + ' \n\n Top 10 most bought items: ' + str(list(df_bot_buy[df_bot_buy['User ID']==int(num)]['Item ID']))
                            

            #case 2: pv + fav
            if int(num) in df_bot_pv['User ID'].unique():
                if int(num) in df_bot_fav['User ID'].unique():
                    return 'Welcome back! Based on your past consumer history, we wish to recommend the following items to you:  \n\n' + 'Top 10 most viewed items: ' + str(list(df_bot_pv[df_bot_pv['User ID']==int(num)]['Item ID'])) + '\n\n Top 10 most favorite items: ' + str(list(df_bot_fav[df_bot_fav['User ID']==int(num)]['Item ID']))
    
            #case 3: pv + cart
            if int(num) in df_bot_pv['User ID'].unique():
                if int(num) in df_bot_cart['User ID'].unique():
                    return 'Welcome back! Based on your past consumer history, we wish to recommend the following items to you:  \n\n' + 'Top 10 most viewed items: ' + str(list(df_bot_pv[df_bot_pv['User ID']==int(num)]['Item ID'])) + '\n\n Top 10 most add to cart items: ' + str(list(df_bot_cart[df_bot_cart['User ID']==int(num)]['Item ID']))
    
            #case 4: pv + cart + buy
            if int(num) in df_bot_pv['User ID'].unique():
                if int(num) in df_bot_cart['User ID'].unique():
                    if int(num) in df_bot_buy['User ID'].unique():
                        return 'Welcome back! Based on your past consumer history, we wish to recommend the following items to you:  \n\n' + 'Top 10 most viewed items: ' + str(list(df_bot_pv[df_bot_pv['User ID']==int(num)]['Item ID'])) + '\n\n Top 10 most add to cart items: ' + str(list(df_bot_cart[df_bot_cart['User ID']==int(num)]['Item ID'])) + '\n\n Top 10 most bought items: ' + str(list(df_bot_buy[df_bot_buy['User ID']==int(num)]['Item ID']))
            
            #case 5: pv
            if int(num) in df_bot_pv['User ID'].unique():
                return 'Welcome back! Based on your past consumer history, we wish to recommend the following items to you:  \n\n' + 'Top 10 most viewed items: ' + str(list(df_bot_pv[df_bot_pv['User ID']==int(num)]['Item ID']))
         
        #recommend top 10 most popular items (consistent for all new users).
        elif int(num)>=4831: 
            return 'Thank you for your first visit! We wish to recommend the following items to you: [141515, 3423, 137441, 142407, 115747, 208890, 133969, 47310, 134392, 120665]'
        else:
            return 'Please provide a valid User ID, which is a user ID between 0 and 4830.'
    except ValueError:
            return 'Invalid input. Please key in valid User ID.'

@app.route('/nameMsg', methods=['POST'])
def nameMsg(update, context):
    user = update.message.from_user
    context.bot.send_message(chat_id=update.effective_chat.id, 
                              text=name(update.message.text))
    return SECOND

@app.route('/userMsg', methods=['POST'])
def userMsg(update, context):    
    user = update.message.from_user
    context.bot.send_message(chat_id=update.effective_chat.id, 
                             # text=update.message.text)
                              text=response(update.message.text))   
    return


@app.route('/help', methods=['POST'])
def help(update, context):
    context.bot.send_message(chat_id=update.message.chat_id, text = "Q: What should I do first when I start the bot?"+ "\n"+"A: Please key in your name if you have NOT done so." + "\n\n" + "Q: I have an existing account with taobao. How should I retrieve my recommendations?" + "\n"+ "A: If you are an existing user, please key in your user ID between 0 to 4830. We would then recommend you the top 10 items to view/add to cart/favorite/purchase based on your user preference history."+ "\n\n"+ "Q: I am a new user, how do I get recommendations?"+ "\n"+ " If you are a new user, we wish to introduce you the top 10 most popular products on our website. Kindly key in your new User ID.")


@app.route('/exit', methods=['POST'])
def exit(update, context):
    context.bot.send_photo(chat_id=update.message.chat_id, photo=open('C:/Users/User/Pictures/byetaobao.JPG', 'rb'))
    context.bot.send_message(chat_id=update.message.chat_id, text = "Kindly press Ctrl-C on the command line to stop the bot.")
        
    
@app.route('/links', methods=['POST'])    
def links(update, context):
    context.bot.send_message(chat_id=update.message.chat_id, text = "Here are the photos and corresponding URLs to our top 10 hot sellers of all time! (In order of priority):" + "\n\n")
    
    #item 1
    context.bot.send_photo(chat_id=update.message.chat_id, photo=open('C:/Users/User/Pictures/item1.JPG', 'rb'))
    context.bot.send_message(chat_id=update.message.chat_id, text = "https://detail.tmall.com/item.htm?spm=a212uc.12510681.1265890180.7.39485e74n6S3dK&acm=lb-zebra-445083-5913228.1003.4.7108901&id=586564770220&scm=1003.4.lb-zebra-445083-5913228.ITEM_586564770220_7108901")   
    #item 2
    context.bot.send_photo(chat_id=update.message.chat_id, photo=open('C:/Users/User/Pictures/item2.JPG', 'rb'))
    context.bot.send_message(chat_id=update.message.chat_id, text = "https://detail.tmall.com/item.htm?spm=a212uc.12510681.1265890180.7.39485e74n6S3dK&acm=lb-zebra-445083-5913228.1003.4.7108901&id=586564770220&scm=1003.4.lb-zebra-445083-5913228.ITEM_586564770220_7108901")
    #item 3
    context.bot.send_photo(chat_id=update.message.chat_id, photo=open('C:/Users/User/Pictures/item3.JPG', 'rb'))
    context.bot.send_message(chat_id=update.message.chat_id, text = "https://detail.tmall.com/item.htm?spm=a212uc.12510681.2367201086.3.39485e74n6S3dK&acm=lb-zebra-445083-5716819.1003.4.6125562&id=586564418860&scm=1003.4.lb-zebra-445083-5716819.ITEM_586564418860_6125562")
    #item 4
    context.bot.send_photo(chat_id=update.message.chat_id, photo=open('C:/Users/User/Pictures/item4.JPG', 'rb'))
    context.bot.send_message(chat_id=update.message.chat_id, text = "https://detail.tmall.com/item.htm?spm=a212uc.12510681.6374292700.4.39485e74n6S3dK&acm=lb-zebra-445083-5716948.1003.4.5193416&id=595307672021&scm=1003.4.lb-zebra-445083-5716948.ITEM_595307672021_5193416")
    #item 5
    context.bot.send_photo(chat_id=update.message.chat_id, photo=open('C:/Users/User/Pictures/item5.JPG', 'rb'))
    context.bot.send_message(chat_id=update.message.chat_id, text = "https://detail.tmall.com/item.htm?spm=a212uc.12510681.5727280828.7.39485e74n6S3dK&acm=lb-zebra-445083-5716793.1003.4.7108930&id=592122594102&scm=1003.4.lb-zebra-445083-5716793.ITEM_592122594102_7108930&sku_properties=5919063:6536025")
    #item 6
    context.bot.send_photo(chat_id=update.message.chat_id, photo=open('C:/Users/User/Pictures/item6.JPG', 'rb'))
    context.bot.send_message(chat_id=update.message.chat_id, text = "https://detail.tmall.com/item.htm?spm=a212uc.12510681.8876145820.2.39485e74n6S3dK&acm=lb-zebra-445083-6769395.1003.4.7108867&id=602405659594&scm=1003.4.lb-zebra-445083-6769395.ITEM_602405659594_7108867&skuId=4212029860055")
    #item7
    context.bot.send_photo(chat_id=update.message.chat_id, photo=open('C:/Users/User/Pictures/item7.JPG', 'rb'))
    context.bot.send_message(chat_id=update.message.chat_id, text = "https://detail.tmall.com/item.htm?spm=a212uc.12510681.2576255250.11.39485e74n6S3dK&acm=lb-zebra-445083-5716892.1003.4.6125538&id=585357737845&scm=1003.4.lb-zebra-445083-5716892.ITEM_585357737845_6125538&skuId=3965591493646")
    #item8
    context.bot.send_photo(chat_id=update.message.chat_id, photo=open('C:/Users/User/Pictures/item8.JPG', 'rb'))
    context.bot.send_message(chat_id=update.message.chat_id, text = "https://detail.tmall.com/item.htm?spm=a212uc.12510681.7655910553.7.39485e74n6S3dK&acm=lb-zebra-445083-6165048.1003.4.6125542&id=587890253558&scm=1003.4.lb-zebra-445083-6165048.ITEM_587890253558_6125542&skuId=4172459150483")
    #item9
    context.bot.send_photo(chat_id=update.message.chat_id, photo=open('C:/Users/User/Pictures/item9.JPG', 'rb'))
    context.bot.send_message(chat_id=update.message.chat_id, text = "https://detail.tmall.com/item.htm?spm=a212uc.12510681.8370422910.3.39485e74n6S3dK&pos=3&acm=lb-zebra-445083-5732421.1003.1.5206150&id=585638271367&scm=1007.13976.92121.0")
    #item10
    context.bot.send_photo(chat_id=update.message.chat_id, photo=open('C:/Users/User/Pictures/item10.JPG', 'rb'))
    context.bot.send_message(chat_id=update.message.chat_id, text = "https://detail.tmall.com/item.htm?spm=a212uc.12510681.4533881272.9.39485e74n6S3dK&acm=lb-zebra-445083-5716928.1003.4.6125595&id=585492550504&scm=1003.4.lb-zebra-445083-5716928.ITEM_585492550504_6125595&sku_properties=1627207:11010012")

@app.route('/main', methods=['POST']) 
def main():
    conv_handler = ConversationHandler(
    entry_points=[CommandHandler('start', start), CommandHandler('help', help), CommandHandler('links', links)],
    states={
        FIRST: [MessageHandler(Filters.text, nameMsg, pass_user_data=True), CommandHandler('help', help), CommandHandler('links', links)],
        SECOND: [MessageHandler(Filters.text, userMsg, pass_user_data=True), CommandHandler('help', help), CommandHandler('links', links)]
    },
    fallbacks=[CommandHandler('exit', exit)]
)
    dispatcher.add_handler(conv_handler)
    thread = Thread(target=dp.start, name='dp')
    thread.start()

    
main()


@app.route('/hook/'+tokens.TOKEN, methods=['GET', 'POST'])
def webhook():
    if request.method == "POST":
        # retrieve the message in JSON and then transform it to Telegram object
        update = Update.de_json(request.get_json(force=True))

        logger.info("Update received! "+ update.message.text)
        dp.process_update(update)
        update_queue.put(update)
        return "OK"
    else:
        return '.'



@app.route('/set_webhook', methods=['GET', 'POST'])
def set_webhook():
    s = bot.setWebhook('{URL}{HOOK}'.format(URL=URL, HOOK=TOKEN))
    if s:
        return "webhook setup ok"
    else:
        return "webhook setup failed"

@app.route('/')
def index():
    return '.'


if __name__ == '__main__':
    app.run(threaded=True)
