bot_token = "862251474:AAFQTrtrpAaqp5fG5vdPdKuEsUu3xMrACps"
bot_user_name = "mytaobao2020_bot"
URL = "https://git.heroku.com/irecommend-taobao.git"